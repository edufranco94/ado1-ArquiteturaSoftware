package Ex05_FactoryMethod;

public enum CoresRGB {
    red,blue,green;
}
