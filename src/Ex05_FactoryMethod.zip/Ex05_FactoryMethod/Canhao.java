package Ex05_FactoryMethod;

public interface Canhao {
    public void atirar();
}
