package Ex05_FactoryMethod;

public interface Cores {
    public void setCores(CoresRGB corTanque,CoresRGB corCanhao);
    
}
