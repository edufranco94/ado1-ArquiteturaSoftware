package Ex05_FactoryMethod;

public interface Posicao {
    public void adPosicaox(double x);
    public double retPosicaox();
    public void adPosicaoy(double y);
    public double retPosicaoy();
 
}
