/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex04;

/**
 *
 * @author Marcos
 */
public class TamanhoArq {
    
    private double tamanho;
    
    public TamanhoArq (double tamanho){
        this.tamanho = tamanho;
    }
    
    
}
